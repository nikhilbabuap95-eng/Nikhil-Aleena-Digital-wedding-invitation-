﻿Netlify upload folder

Drag this entire folder, named netlify-ready, into Netlify's manual deploy area.
Make sure you drag the folder itself, not index.html by itself.
index.html is at the root of this folder; assets contains the photos and music.
